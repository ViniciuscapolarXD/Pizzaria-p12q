module.exports = [
  {
    slug: "margherita",
    name: "Margherita",
    description: "Molho de tomate, mussarela, manjeric\u00e3o fresco e azeite extra virgem.",
    category: "Tradicionais",
    price_cents: 3990,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "calabresa",
    name: "Calabresa",
    description: "Mussarela, calabresa fatiada, cebola roxa e or\u00e9gano.",
    category: "Tradicionais",
    price_cents: 4290,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "quatro-queijos",
    name: "Quatro Queijos",
    description: "Mussarela, parmes\u00e3o, provolone e gorgonzola.",
    category: "Tradicionais",
    price_cents: 4690,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "frango-catupiry",
    name: "Frango com Catupiry",
    description: "Frango desfiado temperado, Catupiry\u00ae e milho.",
    category: "Tradicionais",
    price_cents: 4590,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "portuguesa",
    name: "Portuguesa",
    description: "Mussarela, presunto, ovo, cebola, azeitonas e piment\u00e3o.",
    category: "Tradicionais",
    price_cents: 4690,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "pepperoni",
    name: "Pepperoni",
    description: "Mussarela e pepperoni crocante com toque de pimenta.",
    category: "Especiais",
    price_cents: 4990,
    image: "/img/pizza-6.svg"
  },
  {
    slug: "bbq-bacon",
    name: "BBQ Bacon",
    description: "Molho barbecue, mussarela, bacon e cebola crispy.",
    category: "Especiais",
    price_cents: 5290,
    image: "/img/pizza-7.svg"
  },
  {
    slug: "parma-rucula",
    name: "Parma & R\u00facula",
    description: "Mussarela, presunto parma, r\u00facula e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 5690,
    image: "/img/pizza-8.svg"
  },
  {
    slug: "trufada",
    name: "Trufada",
    description: "Mussarela, cogumelos, toque de trufa e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 5890,
    image: "/img/pizza-9.svg"
  },
  {
    slug: "vegana-verde",
    name: "Vegana Verde",
    description: "Creme de castanhas, br\u00f3colis, tomate seco e manjeric\u00e3o.",
    category: "Veggie",
    price_cents: 5290,
    image: "/img/pizza-10.svg"
  },
  {
    slug: "caprese",
    name: "Caprese",
    description: "Mussarela de b\u00fafala, tomate, manjeric\u00e3o e pesto.",
    category: "Veggie",
    price_cents: 5490,
    image: "/img/pizza-11.svg"
  },
  {
    slug: "chocolate-morango",
    name: "Chocolate com Morango",
    description: "Chocolate ao leite, morangos e raspas.",
    category: "Doces",
    price_cents: 4790,
    image: "/img/pizza-12.svg"
  },
  {
    slug: "banana-canela",
    name: "Banana & Canela",
    description: "Banana caramelizada, canela e leite condensado.",
    category: "Doces",
    price_cents: 4490,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "coca",
    name: "Coca-Cola 2L",
    description: "Refrigerante 2L geladinho.",
    category: "Bebidas",
    price_cents: 1490,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "agua",
    name: "\u00c1gua Mineral 500ml",
    description: "Sem g\u00e1s.",
    category: "Bebidas",
    price_cents: 590,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "cogumelos-0",
    name: "Cogumelos Cremosa",
    description: "Mussarela, mix de cogumelos e salsinha.",
    category: "Especiais",
    price_cents: 5290,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "milho-bacon-1",
    name: "Milho & Bacon Premium",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Tradicionais",
    price_cents: 4590,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "br-colis-2",
    name: "Br\u00f3colis Apimentada",
    description: "Br\u00f3colis, alho dourado e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 5690,
    image: "/img/pizza-6.svg"
  },
  {
    slug: "cogumelos-3",
    name: "Cogumelos Cl\u00e1ssica",
    description: "Mussarela, mix de cogumelos e salsinha.",
    category: "Veggie",
    price_cents: 4790,
    image: "/img/pizza-7.svg"
  },
  {
    slug: "pesto-tomate-seco-4",
    name: "Pesto & Tomate Seco Apimentada",
    description: "Mussarela, pesto e tomate seco.",
    category: "Especiais",
    price_cents: 4790,
    image: "/img/pizza-8.svg"
  },
  {
    slug: "br-colis-5",
    name: "Br\u00f3colis Apimentada",
    description: "Br\u00f3colis, alho dourado e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 5490,
    image: "/img/pizza-9.svg"
  },
  {
    slug: "carne-seca-6",
    name: "Carne Seca Cremosa",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Especiais",
    price_cents: 5490,
    image: "/img/pizza-10.svg"
  },
  {
    slug: "carne-seca-7",
    name: "Carne Seca Caseira",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Especiais",
    price_cents: 5290,
    image: "/img/pizza-11.svg"
  },
  {
    slug: "cebola-caramelizada-8",
    name: "Cebola Caramelizada Cremosa",
    description: "Mussarela, cebola caramelizada e parmes\u00e3o.",
    category: "Tradicionais",
    price_cents: 5690,
    image: "/img/pizza-12.svg"
  },
  {
    slug: "provolone-9",
    name: "Provolone Cl\u00e1ssica",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Tradicionais",
    price_cents: 5490,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "cogumelos-10",
    name: "Cogumelos Premium",
    description: "Mussarela, mix de cogumelos e salsinha.",
    category: "Veggie",
    price_cents: 4590,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "gorgonzola-mel-11",
    name: "Gorgonzola & Mel Cremosa",
    description: "Gorgonzola, mussarela e mel.",
    category: "Especiais",
    price_cents: 4790,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "cebola-caramelizada-12",
    name: "Cebola Caramelizada Premium",
    description: "Mussarela, cebola caramelizada e parmes\u00e3o.",
    category: "Veggie",
    price_cents: 5690,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "pesto-tomate-seco-13",
    name: "Pesto & Tomate Seco Caseira",
    description: "Mussarela, pesto e tomate seco.",
    category: "Veggie",
    price_cents: 5690,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "cogumelos-14",
    name: "Cogumelos Defumada",
    description: "Mussarela, mix de cogumelos e salsinha.",
    category: "Tradicionais",
    price_cents: 4390,
    image: "/img/pizza-6.svg"
  },
  {
    slug: "cebola-caramelizada-15",
    name: "Cebola Caramelizada Cl\u00e1ssica",
    description: "Mussarela, cebola caramelizada e parmes\u00e3o.",
    category: "Tradicionais",
    price_cents: 4990,
    image: "/img/pizza-7.svg"
  },
  {
    slug: "br-colis-16",
    name: "Br\u00f3colis Defumada",
    description: "Br\u00f3colis, alho dourado e parmes\u00e3o.",
    category: "Tradicionais",
    price_cents: 4790,
    image: "/img/pizza-8.svg"
  },
  {
    slug: "cebola-caramelizada-17",
    name: "Cebola Caramelizada Cremosa",
    description: "Mussarela, cebola caramelizada e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 4790,
    image: "/img/pizza-9.svg"
  },
  {
    slug: "gorgonzola-mel-18",
    name: "Gorgonzola & Mel Especial",
    description: "Gorgonzola, mussarela e mel.",
    category: "Tradicionais",
    price_cents: 4790,
    image: "/img/pizza-10.svg"
  },
  {
    slug: "palmito-19",
    name: "Palmito Premium",
    description: "Palmito, tomate e azeitonas.",
    category: "Tradicionais",
    price_cents: 4790,
    image: "/img/pizza-11.svg"
  },
  {
    slug: "pesto-tomate-seco-20",
    name: "Pesto & Tomate Seco Especial",
    description: "Mussarela, pesto e tomate seco.",
    category: "Tradicionais",
    price_cents: 5690,
    image: "/img/pizza-12.svg"
  },
  {
    slug: "carne-seca-21",
    name: "Carne Seca Premium",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Veggie",
    price_cents: 4390,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "gorgonzola-mel-22",
    name: "Gorgonzola & Mel Suprema",
    description: "Gorgonzola, mussarela e mel.",
    category: "Especiais",
    price_cents: 5690,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "milho-bacon-23",
    name: "Milho & Bacon Cremosa",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Tradicionais",
    price_cents: 4390,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "provolone-24",
    name: "Provolone Suprema",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Especiais",
    price_cents: 5290,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "gorgonzola-mel-25",
    name: "Gorgonzola & Mel Especial",
    description: "Gorgonzola, mussarela e mel.",
    category: "Especiais",
    price_cents: 4790,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "gorgonzola-mel-26",
    name: "Gorgonzola & Mel Cremosa",
    description: "Gorgonzola, mussarela e mel.",
    category: "Especiais",
    price_cents: 4790,
    image: "/img/pizza-6.svg"
  },
  {
    slug: "provolone-27",
    name: "Provolone Especial",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Tradicionais",
    price_cents: 5290,
    image: "/img/pizza-7.svg"
  },
  {
    slug: "cebola-caramelizada-28",
    name: "Cebola Caramelizada Artesanal",
    description: "Mussarela, cebola caramelizada e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 4590,
    image: "/img/pizza-8.svg"
  },
  {
    slug: "gorgonzola-mel-29",
    name: "Gorgonzola & Mel Caseira",
    description: "Gorgonzola, mussarela e mel.",
    category: "Veggie",
    price_cents: 4990,
    image: "/img/pizza-9.svg"
  },
  {
    slug: "milho-bacon-30",
    name: "Milho & Bacon Artesanal",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Especiais",
    price_cents: 5690,
    image: "/img/pizza-10.svg"
  },
  {
    slug: "milho-bacon-31",
    name: "Milho & Bacon Premium",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Especiais",
    price_cents: 5490,
    image: "/img/pizza-11.svg"
  },
  {
    slug: "cebola-caramelizada-32",
    name: "Cebola Caramelizada Apimentada",
    description: "Mussarela, cebola caramelizada e parmes\u00e3o.",
    category: "Veggie",
    price_cents: 5290,
    image: "/img/pizza-12.svg"
  },
  {
    slug: "pesto-tomate-seco-33",
    name: "Pesto & Tomate Seco Cremosa",
    description: "Mussarela, pesto e tomate seco.",
    category: "Veggie",
    price_cents: 4590,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "provolone-34",
    name: "Provolone Cremosa",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Especiais",
    price_cents: 5290,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "milho-bacon-35",
    name: "Milho & Bacon Premium",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Veggie",
    price_cents: 4990,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "cogumelos-36",
    name: "Cogumelos Premium",
    description: "Mussarela, mix de cogumelos e salsinha.",
    category: "Especiais",
    price_cents: 5490,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "palmito-37",
    name: "Palmito Cl\u00e1ssica",
    description: "Palmito, tomate e azeitonas.",
    category: "Especiais",
    price_cents: 5690,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "milho-bacon-38",
    name: "Milho & Bacon Artesanal",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Tradicionais",
    price_cents: 5490,
    image: "/img/pizza-6.svg"
  },
  {
    slug: "carne-seca-39",
    name: "Carne Seca Defumada",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Veggie",
    price_cents: 5690,
    image: "/img/pizza-7.svg"
  },
  {
    slug: "cebola-caramelizada-40",
    name: "Cebola Caramelizada Cremosa",
    description: "Mussarela, cebola caramelizada e parmes\u00e3o.",
    category: "Tradicionais",
    price_cents: 4990,
    image: "/img/pizza-8.svg"
  },
  {
    slug: "provolone-41",
    name: "Provolone Cl\u00e1ssica",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Tradicionais",
    price_cents: 4790,
    image: "/img/pizza-9.svg"
  },
  {
    slug: "provolone-42",
    name: "Provolone Suprema",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Especiais",
    price_cents: 4390,
    image: "/img/pizza-10.svg"
  },
  {
    slug: "provolone-43",
    name: "Provolone Cremosa",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Especiais",
    price_cents: 4790,
    image: "/img/pizza-11.svg"
  },
  {
    slug: "carne-seca-44",
    name: "Carne Seca Defumada",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Tradicionais",
    price_cents: 4390,
    image: "/img/pizza-12.svg"
  },
  {
    slug: "gorgonzola-mel-45",
    name: "Gorgonzola & Mel Apimentada",
    description: "Gorgonzola, mussarela e mel.",
    category: "Tradicionais",
    price_cents: 5690,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "milho-bacon-46",
    name: "Milho & Bacon Artesanal",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Tradicionais",
    price_cents: 4790,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "provolone-47",
    name: "Provolone Premium",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Veggie",
    price_cents: 4390,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "gorgonzola-mel-48",
    name: "Gorgonzola & Mel Defumada",
    description: "Gorgonzola, mussarela e mel.",
    category: "Especiais",
    price_cents: 4790,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "br-colis-49",
    name: "Br\u00f3colis Gourmet",
    description: "Br\u00f3colis, alho dourado e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 5490,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "br-colis-50",
    name: "Br\u00f3colis Gourmet",
    description: "Br\u00f3colis, alho dourado e parmes\u00e3o.",
    category: "Especiais",
    price_cents: 5490,
    image: "/img/pizza-6.svg"
  },
  {
    slug: "palmito-51",
    name: "Palmito Suprema",
    description: "Palmito, tomate e azeitonas.",
    category: "Tradicionais",
    price_cents: 4590,
    image: "/img/pizza-7.svg"
  },
  {
    slug: "pesto-tomate-seco-52",
    name: "Pesto & Tomate Seco Apimentada",
    description: "Mussarela, pesto e tomate seco.",
    category: "Especiais",
    price_cents: 4990,
    image: "/img/pizza-8.svg"
  },
  {
    slug: "gorgonzola-mel-53",
    name: "Gorgonzola & Mel Apimentada",
    description: "Gorgonzola, mussarela e mel.",
    category: "Tradicionais",
    price_cents: 4590,
    image: "/img/pizza-9.svg"
  },
  {
    slug: "palmito-54",
    name: "Palmito Artesanal",
    description: "Palmito, tomate e azeitonas.",
    category: "Especiais",
    price_cents: 4990,
    image: "/img/pizza-10.svg"
  },
  {
    slug: "carne-seca-55",
    name: "Carne Seca Suprema",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Tradicionais",
    price_cents: 4390,
    image: "/img/pizza-11.svg"
  },
  {
    slug: "cogumelos-56",
    name: "Cogumelos Especial",
    description: "Mussarela, mix de cogumelos e salsinha.",
    category: "Tradicionais",
    price_cents: 4790,
    image: "/img/pizza-12.svg"
  },
  {
    slug: "gorgonzola-mel-57",
    name: "Gorgonzola & Mel Artesanal",
    description: "Gorgonzola, mussarela e mel.",
    category: "Especiais",
    price_cents: 5690,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "atum-58",
    name: "Atum Suprema",
    description: "Atum, cebola, azeitonas e or\u00e9gano.",
    category: "Especiais",
    price_cents: 4390,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "br-colis-59",
    name: "Br\u00f3colis Suprema",
    description: "Br\u00f3colis, alho dourado e parmes\u00e3o.",
    category: "Tradicionais",
    price_cents: 5690,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "gorgonzola-mel-60",
    name: "Gorgonzola & Mel Caseira",
    description: "Gorgonzola, mussarela e mel.",
    category: "Tradicionais",
    price_cents: 5290,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "provolone-61",
    name: "Provolone Gourmet",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Especiais",
    price_cents: 5490,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "pesto-tomate-seco-62",
    name: "Pesto & Tomate Seco Apimentada",
    description: "Mussarela, pesto e tomate seco.",
    category: "Tradicionais",
    price_cents: 4990,
    image: "/img/pizza-6.svg"
  },
  {
    slug: "palmito-63",
    name: "Palmito Defumada",
    description: "Palmito, tomate e azeitonas.",
    category: "Tradicionais",
    price_cents: 4590,
    image: "/img/pizza-7.svg"
  },
  {
    slug: "provolone-64",
    name: "Provolone Cl\u00e1ssica",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Veggie",
    price_cents: 4590,
    image: "/img/pizza-8.svg"
  },
  {
    slug: "palmito-65",
    name: "Palmito Gourmet",
    description: "Palmito, tomate e azeitonas.",
    category: "Tradicionais",
    price_cents: 4590,
    image: "/img/pizza-9.svg"
  },
  {
    slug: "carne-seca-66",
    name: "Carne Seca Suprema",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Tradicionais",
    price_cents: 4990,
    image: "/img/pizza-10.svg"
  },
  {
    slug: "provolone-67",
    name: "Provolone Suprema",
    description: "Provolone, tomate e manjeric\u00e3o.",
    category: "Veggie",
    price_cents: 4990,
    image: "/img/pizza-11.svg"
  },
  {
    slug: "palmito-68",
    name: "Palmito Caseira",
    description: "Palmito, tomate e azeitonas.",
    category: "Veggie",
    price_cents: 5690,
    image: "/img/pizza-12.svg"
  },
  {
    slug: "milho-bacon-69",
    name: "Milho & Bacon Suprema",
    description: "Mussarela, milho, bacon e or\u00e9gano.",
    category: "Veggie",
    price_cents: 4390,
    image: "/img/pizza-1.svg"
  },
  {
    slug: "carne-seca-70",
    name: "Carne Seca Premium",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Tradicionais",
    price_cents: 4590,
    image: "/img/pizza-2.svg"
  },
  {
    slug: "atum-71",
    name: "Atum Caseira",
    description: "Atum, cebola, azeitonas e or\u00e9gano.",
    category: "Tradicionais",
    price_cents: 4790,
    image: "/img/pizza-3.svg"
  },
  {
    slug: "carne-seca-72",
    name: "Carne Seca Defumada",
    description: "Carne seca desfiada, cebola roxa e catupiry\u00ae.",
    category: "Especiais",
    price_cents: 4990,
    image: "/img/pizza-4.svg"
  },
  {
    slug: "gorgonzola-mel-73",
    name: "Gorgonzola & Mel Suprema",
    description: "Gorgonzola, mussarela e mel.",
    category: "Veggie",
    price_cents: 4590,
    image: "/img/pizza-5.svg"
  },
  {
    slug: "gorgonzola-mel-74",
    name: "Gorgonzola & Mel Artesanal",
    description: "Gorgonzola, mussarela e mel.",
    category: "Tradicionais",
    price_cents: 4390,
    image: "/img/pizza-6.svg"
  },
];
