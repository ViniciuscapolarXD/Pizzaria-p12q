# Pizzaria — 12 páginas (HTML server-side) + Login + Pedidos salvos + Stripe (pagamento real)

Este projeto é um site **funcional** de pizzaria com:
- **12 páginas** (rotas) renderizadas com EJS (HTML).
- **Login/Registro** com senha **hash (bcrypt)**.
- **Carrinho** e **pedidos salvos** em **SQLite**.
- **Pagamento real** com **Stripe Checkout** (você pode usar **test** ou **live** — basta colocar as chaves).

> Importante: eu não consigo criar sua conta Stripe nem colocar chaves reais por você.  
> O código está pronto para **pagamento real** — você só precisa inserir suas chaves (e configurar webhook).

## 1) Requisitos
- Node.js 18+ (recomendado)
- Conta Stripe (para receber pagamentos)

## 2) Rodar localmente
```bash
npm install
cp .env.example .env
npm run dev
```

Abra:
- http://localhost:3000

## 3) Configurar Stripe (pagamento)
No painel da Stripe, pegue:
- `STRIPE_SECRET_KEY` (chave secreta)
- Crie um endpoint de webhook e copie o `STRIPE_WEBHOOK_SECRET`

Docs oficiais:
- Checkout Sessions: https://docs.stripe.com/api/checkout/sessions/create?lang=node
- Webhooks: https://docs.stripe.com/webhooks

### Webhook local
Para testar webhooks localmente, use o **Stripe CLI** ou um túnel (ex: ngrok).
- O endpoint do projeto é: `POST /webhook/stripe`

## 4) Deploy
Você pode subir em Render / Railway / Fly.io / VPS.
- Configure as variáveis de ambiente do `.env`.

## 5) GitHub (opcional)
```bash
git init
git add .
git commit -m "pizzaria 12 páginas"
git branch -M main
git remote add origin <URL_DO_SEU_REPO>
git push -u origin main
```

---

## Páginas (12)
1. Home `/`
2. Cardápio `/menu`
3. Pizza (detalhe) `/pizza/:id`
4. Carrinho `/cart`
5. Checkout `/checkout`
6. Login `/login`
7. Cadastro `/register`
8. Minha conta `/account`
9. Meus pedidos `/orders`
10. Sobre `/about`
11. Contato `/contact`
12. Privacidade `/privacy`

## Observação sobre “nada simulado”
- O **Stripe Checkout** é um gateway real; com **chaves live** ele cobra de verdade.
- Em modo **test**, ele funciona completo (mas sem cobrar dinheiro real). Você escolhe.
