/**
 * Pizzaria — 12 páginas, login real (bcrypt+session), pedidos salvos (SQLite) e pagamento real (Stripe Checkout).
 *
 * Rotas (12 páginas):
 * 1) GET  /            (home)
 * 2) GET  /menu        (cardápio)
 * 3) GET  /pizza/:id   (detalhe)
 * 4) GET  /cart        (carrinho)
 * 5) GET  /checkout    (checkout)
 * 6) GET  /login       (login)
 * 7) GET  /register    (cadastro)
 * 8) GET  /account     (minha conta)
 * 9) GET  /orders      (meus pedidos)
 * 10) GET /about       (sobre)
 * 11) GET /contact     (contato)
 * 12) GET /privacy     (privacidade)
 *
 * Extras (não contam como páginas):
 * - POST /cart/add, /cart/update, /cart/remove
 * - POST /auth/login, /auth/register, POST /logout
 * - POST /checkout/create-session
 * - POST /webhook/stripe
 */

require("dotenv").config();

const path = require("path");
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const morgan = require("morgan");
const bcrypt = require("bcrypt");
const Stripe = require("stripe");
const SQLiteStoreFactory = require("connect-sqlite3");

const { init, get, all, run } = require("./db");

// -------------------- Config --------------------
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const SESSION_SECRET = process.env.SESSION_SECRET || "troque-esta-string";
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || "";

if (!STRIPE_SECRET_KEY) {
  console.warn("[AVISO] STRIPE_SECRET_KEY está vazio. Checkout não vai funcionar até você configurar o .env.");
}

const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null;

const app = express();

// Segurança básica de headers
app.use(helmet({
  contentSecurityPolicy: false, // simplifica para começar (você pode reforçar depois)
}));

app.use(morgan("dev"));

// -------------------- Stripe Webhook (RAW BODY) --------------------
// Stripe exige o corpo *raw* para validar a assinatura. (docs: webhooks)
app.post("/webhook/stripe", express.raw({ type: "application/json" }), async (req, res) => {
  if (!stripe || !STRIPE_WEBHOOK_SECRET) {
    return res.status(400).send("Stripe não configurado.");
  }

  const sig = req.headers["stripe-signature"];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("[WEBHOOK] assinatura inválida:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    if (event.type === "checkout.session.completed") {
      const sessionObj = event.data.object;

      const orderId = sessionObj?.metadata?.order_id ? Number(sessionObj.metadata.order_id) : null;
      const sessionId = sessionObj.id;

      if (orderId) {
        // marca como pago
        await run(
          `UPDATE orders
           SET status = ?, stripe_session_id = ?, stripe_payment_intent_id = ?, customer_email = ?, paid_at = ?
           WHERE id = ?`,
          [
            "paid",
            sessionId,
            sessionObj.payment_intent || null,
            sessionObj.customer_details?.email || sessionObj.customer_email || null,
            new Date().toISOString(),
            orderId,
          ]
        );
      } else {
        console.warn("[WEBHOOK] checkout.session.completed sem order_id em metadata.");
      }
    }
  } catch (e) {
    console.error("[WEBHOOK] erro processando evento:", e);
    return res.status(500).send("Erro interno no webhook.");
  }

  res.json({ received: true });
});

// -------------------- Body parsers (não use json antes do webhook) --------------------
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// -------------------- Sessions --------------------
const SQLiteStore = SQLiteStoreFactory(session);
app.use(
  session({
    store: new SQLiteStore({
      dir: path.join(__dirname, "sessions"),
      db: "sessions.sqlite",
      concurrentDB: true,
    }),
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: false, // true em HTTPS
      maxAge: 1000 * 60 * 60 * 24 * 14, // 14 dias
    },
  })
);

// -------------------- Views + Static --------------------
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static(path.join(__dirname, "public")));
app.use("/public", express.static(path.join(__dirname, "public")));

// -------------------- Helpers --------------------
function formatBRL(cents) {
  const v = (cents || 0) / 100;
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);
}

function ensureCart(req) {
  if (!req.session.cart) {
    req.session.cart = { items: {}, created_at: Date.now(), updated_at: Date.now() };
  }
  return req.session.cart;
}

function cartCount(cart) {
  if (!cart || !cart.items) return 0;
  return Object.values(cart.items).reduce((acc, q) => acc + (Number(q) || 0), 0);
}

async function cartDetails(req) {
  const cart = ensureCart(req);
  const ids = Object.keys(cart.items).map((x) => Number(x)).filter(Boolean);
  if (ids.length === 0) return { items: [], subtotal_cents: 0 };

  const placeholders = ids.map(() => "?").join(",");
  const pizzas = await all(`SELECT * FROM pizzas WHERE id IN (${placeholders}) AND is_active = 1`, ids);

  let subtotal = 0;
  const items = pizzas.map((p) => {
    const qty = Number(cart.items[p.id]) || 0;
    const line = qty * p.price_cents;
    subtotal += line;
    return {
      pizza_id: p.id,
      slug: p.slug,
      name: p.name,
      description: p.description,
      category: p.category,
      price_cents: p.price_cents,
      price_brl: formatBRL(p.price_cents),
      qty,
      line_cents: line,
      line_brl: formatBRL(line),
      image: p.image,
    };
  }).filter(x => x.qty > 0);

  return { items, subtotal_cents: subtotal, subtotal_brl: formatBRL(subtotal) };
}

function requireAuth(req, res, next) {
  if (!req.session.user_id) {
    const nextUrl = encodeURIComponent(req.originalUrl || "/");
    return res.redirect(`/login?next=${nextUrl}`);
  }
  next();
}

async function loadUser(req, res, next) {
  res.locals.currentUser = null;
  if (req.session.user_id) {
    const u = await get(`SELECT id, name, email, created_at FROM users WHERE id = ?`, [req.session.user_id]);
    res.locals.currentUser = u || null;
  }
  const cart = ensureCart(req);
  res.locals.cartCount = cartCount(cart);
  res.locals.formatBRL = formatBRL;
  res.locals.baseUrl = BASE_URL;
  next();
}

app.use(loadUser);

// -------------------- Init DB --------------------
init().then(() => {
  console.log("✅ Banco pronto.");
}).catch((e) => {
  console.error("❌ Erro inicializando DB:", e);
  process.exit(1);
});

// -------------------- Pages (12) --------------------

// 1) Home
app.get("/", async (req, res) => {
  const featured = await all(`SELECT * FROM pizzas WHERE is_active = 1 ORDER BY RANDOM() LIMIT 8;`);
  res.render("home", { featured });
});

// 2) Cardápio
app.get("/menu", async (req, res) => {
  const pizzas = await all(`SELECT * FROM pizzas WHERE is_active = 1 ORDER BY category, name;`);
  const grouped = pizzas.reduce((acc, p) => {
    acc[p.category] = acc[p.category] || [];
    acc[p.category].push(p);
    return acc;
  }, {});
  res.render("menu", { grouped });
});

// 3) Pizza detalhe
app.get("/pizza/:id", async (req, res) => {
  const id = Number(req.params.id);
  const pizza = await get(`SELECT * FROM pizzas WHERE id = ? AND is_active = 1`, [id]);
  if (!pizza) return res.status(404).render("message", { title: "Pizza não encontrada", message: "Essa pizza não existe (ou saiu do cardápio)." });

  res.render("pizza", { pizza });
});

// 4) Carrinho
app.get("/cart", async (req, res) => {
  const details = await cartDetails(req);
  res.render("cart", { cart: details });
});

// 5) Checkout (requer login)
app.get("/checkout", requireAuth, async (req, res) => {
  const details = await cartDetails(req);
  if (details.items.length === 0) {
    return res.redirect("/cart");
  }
  res.render("checkout", { cart: details, stripeEnabled: Boolean(stripe) });
});

// 6) Login
app.get("/login", (req, res) => {
  res.render("login", { next: req.query.next || "/" });
});

// 7) Cadastro
app.get("/register", (req, res) => {
  res.render("register", { next: req.query.next || "/" });
});

// 8) Conta
app.get("/account", requireAuth, async (req, res) => {
  const user = await get(`SELECT id, name, email, created_at FROM users WHERE id = ?`, [req.session.user_id]);
  res.render("account", { user });
});

// 9) Pedidos
app.get("/orders", requireAuth, async (req, res) => {
  const orders = await all(
    `SELECT id, status, total_cents, currency, created_at, paid_at
     FROM orders
     WHERE user_id = ?
     ORDER BY id DESC
     LIMIT 50;`,
    [req.session.user_id]
  );

  // itens de cada pedido (para mostrar resumo)
  const orderIds = orders.map(o => o.id);
  let itemsByOrder = {};
  if (orderIds.length) {
    const placeholders = orderIds.map(() => "?").join(",");
    const items = await all(
      `SELECT order_id, name, qty, unit_cents
       FROM order_items
       WHERE order_id IN (${placeholders})
       ORDER BY order_id DESC, id ASC;`,
      orderIds
    );
    for (const it of items) {
      itemsByOrder[it.order_id] = itemsByOrder[it.order_id] || [];
      itemsByOrder[it.order_id].push(it);
    }
  }

  res.render("orders", { orders, itemsByOrder, paid: req.query.paid || null, canceled: req.query.canceled || null });
});

// 10) Sobre
app.get("/about", (req, res) => res.render("about"));

// 11) Contato
app.get("/contact", (req, res) => res.render("contact", { sent: req.query.sent || null }));

// 12) Privacidade
app.get("/privacy", (req, res) => res.render("privacy"));

// -------------------- Contact action (salva de verdade no SQLite) --------------------
app.post("/contact", async (req, res) => {
  const name = (req.body.name || "").trim();
  const email = (req.body.email || "").trim().toLowerCase();
  const message = (req.body.message || "").trim();

  if (!name || !email || !message) {
    return res.status(400).render("message", { title: "Contato", message: "Preencha nome, email e mensagem.", back: "/contact" });
  }

  await run(
    `INSERT INTO contact_messages (name, email, message, created_at) VALUES (?, ?, ?, ?)`,
    [name, email, message, new Date().toISOString()]
  );

  // redireciona com flag
  res.redirect("/contact?sent=1");
});


// -------------------- Auth actions --------------------
app.post("/auth/register", async (req, res) => {
  const name = (req.body.name || "").trim();
  const email = (req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const next = req.body.next || "/";

  if (!name || !email || password.length < 8) {
    return res.status(400).render("message", {
      title: "Cadastro inválido",
      message: "Preencha nome, email e uma senha de pelo menos 8 caracteres.",
      back: "/register"
    });
  }

  try {
    const rounds = 11; // equilíbrio entre segurança e performance
    const password_hash = await bcrypt.hash(password, rounds);
    const created_at = new Date().toISOString();

    const result = await run(
      `INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)`,
      [name, email, password_hash, created_at]
    );

    req.session.user_id = result.lastID;
    res.redirect(next);
  } catch (e) {
    if (String(e.message || "").includes("UNIQUE")) {
      return res.status(400).render("message", { title: "Email já cadastrado", message: "Esse email já está em uso. Faça login.", back: "/login" });
    }
    console.error(e);
    res.status(500).render("message", { title: "Erro", message: "Não foi possível criar sua conta agora.", back: "/register" });
  }
});

app.post("/auth/login", async (req, res) => {
  const email = (req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const next = req.body.next || "/";

  const user = await get(`SELECT * FROM users WHERE email = ?`, [email]);
  if (!user) {
    return res.status(400).render("message", { title: "Login inválido", message: "Email ou senha incorretos.", back: "/login" });
  }

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) {
    return res.status(400).render("message", { title: "Login inválido", message: "Email ou senha incorretos.", back: "/login" });
  }

  req.session.user_id = user.id;
  res.redirect(next);
});

app.post("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/"));
});

// -------------------- Cart actions --------------------
app.post("/cart/add", async (req, res) => {
  const id = Number(req.body.pizza_id);
  const qty = Math.max(1, Math.min(50, Number(req.body.qty) || 1));

  const pizza = await get(`SELECT id FROM pizzas WHERE id = ? AND is_active = 1`, [id]);
  if (!pizza) return res.status(404).render("message", { title: "Erro", message: "Item inválido.", back: "/menu" });

  const cart = ensureCart(req);
  cart.items[id] = (Number(cart.items[id]) || 0) + qty;
  cart.updated_at = Date.now();
  req.session.cart = cart;

  const redirectTo = req.body.redirect_to || "/cart";
  res.redirect(redirectTo);
});

app.post("/cart/update", (req, res) => {
  const cart = ensureCart(req);
  const updates = req.body.qty || {};
  for (const [idStr, qtyStr] of Object.entries(updates)) {
    const id = Number(idStr);
    let q = Number(qtyStr);
    if (!Number.isFinite(q)) q = 0;
    q = Math.max(0, Math.min(50, Math.floor(q)));
    if (q <= 0) delete cart.items[id];
    else cart.items[id] = q;
  }
  cart.updated_at = Date.now();
  req.session.cart = cart;
  res.redirect("/cart");
});

app.post("/cart/remove", (req, res) => {
  const id = Number(req.body.pizza_id);
  const cart = ensureCart(req);
  delete cart.items[id];
  cart.updated_at = Date.now();
  req.session.cart = cart;
  res.redirect("/cart");
});

// -------------------- Checkout action --------------------
app.post("/checkout/create-session", requireAuth, async (req, res) => {
  if (!stripe) {
    return res.status(500).render("message", { title: "Pagamento indisponível", message: "Stripe não configurado.", back: "/checkout" });
  }

  const details = await cartDetails(req);
  if (details.items.length === 0) return res.redirect("/cart");

  // Captura endereço (nada “simulado”: salvamos mesmo)
  const delivery = {
    delivery_name: (req.body.delivery_name || "").trim(),
    delivery_phone: (req.body.delivery_phone || "").trim(),
    delivery_address1: (req.body.delivery_address1 || "").trim(),
    delivery_address2: (req.body.delivery_address2 || "").trim(),
    delivery_neighborhood: (req.body.delivery_neighborhood || "").trim(),
    delivery_city: (req.body.delivery_city || "").trim(),
    delivery_state: (req.body.delivery_state || "").trim(),
    delivery_zip: (req.body.delivery_zip || "").trim(),
    notes: (req.body.notes || "").trim(),
  };

  // validação mínima
  const requiredFields = ["delivery_name","delivery_phone","delivery_address1","delivery_neighborhood","delivery_city","delivery_state","delivery_zip"];
  for (const f of requiredFields) {
    if (!delivery[f]) {
      return res.status(400).render("message", { title: "Endereço incompleto", message: "Preencha todos os campos obrigatórios do endereço.", back: "/checkout" });
    }
  }

  // Cria pedido no banco como "pending_payment"
  const created_at = new Date().toISOString();
  const currency = "brl";
  const orderInsert = await run(
    `INSERT INTO orders
     (user_id, status, total_cents, currency, stripe_session_id, stripe_payment_intent_id, customer_email,
      delivery_name, delivery_phone, delivery_address1, delivery_address2, delivery_neighborhood, delivery_city, delivery_state, delivery_zip, notes, created_at)
     VALUES (?, ?, ?, ?, NULL, NULL, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      req.session.user_id,
      "pending_payment",
      details.subtotal_cents,
      currency,
      delivery.delivery_name,
      delivery.delivery_phone,
      delivery.delivery_address1,
      delivery.delivery_address2 || null,
      delivery.delivery_neighborhood,
      delivery.delivery_city,
      delivery.delivery_state,
      delivery.delivery_zip,
      delivery.notes || null,
      created_at
    ]
  );

  const orderId = orderInsert.lastID;

  // salva itens do pedido
  for (const it of details.items) {
    await run(
      `INSERT INTO order_items (order_id, pizza_id, name, unit_cents, qty) VALUES (?, ?, ?, ?, ?)`,
      [orderId, it.pizza_id, it.name, it.price_cents, it.qty]
    );
  }

  // Monta line items para o Stripe diretamente do banco (evita fraude no preço)
  const line_items = details.items.map((it) => ({
    quantity: it.qty,
    price_data: {
      currency,
      unit_amount: it.price_cents,
      product_data: {
        name: it.name,
        description: it.description,
        images: it.image ? [`${BASE_URL}${it.image}`] : undefined,
      },
    },
  }));

  try {
    const sessionCreated = await stripe.checkout.sessions.create({
      mode: "payment",
      success_url: `${BASE_URL}/orders?paid=1`,
      cancel_url: `${BASE_URL}/checkout?canceled=1`,
      line_items,
      metadata: {
        order_id: String(orderId),
        user_id: String(req.session.user_id),
      },
    });

    // Atualiza session id no pedido
    await run(`UPDATE orders SET stripe_session_id = ? WHERE id = ?`, [sessionCreated.id, orderId]);

    // Limpa carrinho (mas ainda dá para ver pedido em /orders mesmo se cancelar)
    req.session.cart = { items: {}, created_at: Date.now(), updated_at: Date.now() };

    // Redireciona para o Checkout hospedado da Stripe
    return res.redirect(303, sessionCreated.url);
  } catch (e) {
    console.error("[CHECKOUT] erro criando sessão Stripe:", e);
    return res.status(500).render("message", { title: "Erro no pagamento", message: "Não foi possível iniciar o pagamento agora.", back: "/checkout" });
  }
});

// -------------------- API simples (opcional) --------------------
// Para o frontend buscar dados (não necessário, mas útil em algumas UIs)
app.get("/api/menu", async (req, res) => {
  const pizzas = await all(`SELECT id, slug, name, description, category, price_cents, image FROM pizzas WHERE is_active = 1 ORDER BY category, name`);
  res.json({ pizzas });
});

// -------------------- 404 --------------------
app.use((req, res) => {
  res.status(404).render("message", { title: "404", message: "Página não encontrada.", back: "/" });
});

// -------------------- Start --------------------
app.listen(PORT, () => {
  console.log(`🍕 Pizzaria rodando em ${BASE_URL}`);
});
