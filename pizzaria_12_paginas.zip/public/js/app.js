/* Pizzaria Aurora — JS pequeno (interações de UI)
   - filtro e busca no /menu
   - aviso do contato (front-end)
*/

(function () {
  "use strict";

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.from((root || document).querySelectorAll(sel)); }

  // -------------------- Menu filter/search --------------------
  const filterRoot = document.querySelector("[data-filter-root]");
  if (filterRoot) {
    const chips = $all("[data-filter]", filterRoot);
    const search = $("[data-search]", filterRoot);
    const categories = $all("[data-category]");

    function normalize(s) {
      return (s || "")
        .toString()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
    }

    function apply() {
      const activeChip = chips.find(c => c.classList.contains("is-active"));
      const activeCat = activeChip ? activeChip.getAttribute("data-filter") : "*";
      const q = normalize(search ? search.value : "");

      categories.forEach(catEl => {
        const catName = catEl.getAttribute("data-category");
        const matchCat = (activeCat === "*") || (activeCat === catName);

        // busca dentro dos cards
        const cards = $all(".card", catEl);
        let visibleCount = 0;

        cards.forEach(card => {
          const txt = normalize(card.innerText);
          const matchQ = !q || txt.includes(q);
          const show = matchCat && matchQ;
          card.style.display = show ? "" : "none";
          if (show) visibleCount++;
        });

        catEl.style.display = (matchCat && visibleCount > 0) ? "" : "none";
      });
    }

    chips.forEach(chip => {
      chip.addEventListener("click", () => {
        chips.forEach(c => c.classList.remove("is-active"));
        chip.classList.add("is-active");
        apply();
      });
    });

    if (search) {
      search.addEventListener("input", apply);
    }

    apply();
  }

  // -------------------- Fake contact (visual) --------------------
  window.fakeContactSubmit = function (e) {
    e.preventDefault();
    alert("Formulário de contato é só visual neste template. Para envio real, conecte um backend/serviço.");
    return false;
  };

  // -------------------- Small: animate counters --------------------
  // microinteração simples e barata
  const stats = document.querySelectorAll(".stat strong");
  stats.forEach(el => {
    const txt = el.textContent.trim();
    if (!/^\+?\d+/.test(txt)) return;

    const num = Number(txt.replace("+",""));
    if (!Number.isFinite(num) || num <= 0 || num > 9999) return;

    let cur = 0;
    const steps = 20;
    const inc = Math.max(1, Math.floor(num / steps));
    const tick = () => {
      cur += inc;
      if (cur >= num) {
        el.textContent = txt;
        return;
      }
      el.textContent = (txt.startsWith("+") ? "+" : "") + String(cur);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });

})();
