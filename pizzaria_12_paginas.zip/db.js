const path = require("path");
const fs = require("fs");
const sqlite3 = require("sqlite3").verbose();

/**
 * Banco de dados SQLite simples.
 * - Arquivo: /data/pizzaria.db
 * - Cria tabelas se não existirem
 * - Seed do cardápio na primeira execução
 */

const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, "pizzaria.db");

const db = new sqlite3.Database(dbPath);

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

async function init() {
  // Segurança: foreign_keys
  await run(`PRAGMA foreign_keys = ON;`);

  await run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS pizzas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      category TEXT NOT NULL,
      price_cents INTEGER NOT NULL,
      image TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1
    );
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      status TEXT NOT NULL,
      total_cents INTEGER NOT NULL,
      currency TEXT NOT NULL,
      stripe_session_id TEXT,
      stripe_payment_intent_id TEXT,
      customer_email TEXT,
      delivery_name TEXT NOT NULL,
      delivery_phone TEXT NOT NULL,
      delivery_address1 TEXT NOT NULL,
      delivery_address2 TEXT,
      delivery_neighborhood TEXT NOT NULL,
      delivery_city TEXT NOT NULL,
      delivery_state TEXT NOT NULL,
      delivery_zip TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL,
      paid_at TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      pizza_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      unit_cents INTEGER NOT NULL,
      qty INTEGER NOT NULL,
      FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY(pizza_id) REFERENCES pizzas(id) ON DELETE RESTRICT
    );
  `);
  await run(`
    CREATE TABLE IF NOT EXISTS contact_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);


  // Seed do cardápio se estiver vazio
  const countRow = await get(`SELECT COUNT(*) AS c FROM pizzas;`);
  if (!countRow || countRow.c === 0) {
    const seed = require("./seed_pizzas");
    for (const p of seed) {
      await run(
        `INSERT INTO pizzas (slug, name, description, category, price_cents, image, is_active)
         VALUES (?, ?, ?, ?, ?, ?, 1);`,
        [p.slug, p.name, p.description, p.category, p.price_cents, p.image]
      );
    }
  }
}

module.exports = { db, run, get, all, init, dbPath };
